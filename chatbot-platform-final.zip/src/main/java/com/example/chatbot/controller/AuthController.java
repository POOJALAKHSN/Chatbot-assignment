package com.example.chatbot.controller;

import com.example.chatbot.dto.*;
import com.example.chatbot.entity.User;
import com.example.chatbot.service.UserService;
import com.example.chatbot.config.JwtUtils;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final UserService userService;
    private final JwtUtils jwtUtils;

    public AuthController(UserService userService, JwtUtils jwtUtils) {
        this.userService = userService;
        this.jwtUtils = jwtUtils;
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterRequest req) {
        Optional<User> exists = userService.findByEmail(req.getEmail());
        if (exists.isPresent()) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body("Email already in use");
        }
        User u = userService.register(req.getEmail(), req.getPassword(), req.getFullName());
        String token = jwtUtils.generateToken(u.getEmail());
        return ResponseEntity.ok(new AuthResponse(token));
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody AuthRequest req) {
        Optional<User> opt = userService.findByEmail(req.getEmail());
        if (!opt.isPresent()) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
        User u = opt.get();
        if (!userService.checkPassword(req.getPassword(), u.getPasswordHash())) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
        }
        String token = jwtUtils.generateToken(u.getEmail());
        return ResponseEntity.ok(new AuthResponse(token));
    }
}
