package com.example.chatbot.controller;

import com.example.chatbot.entity.*;
import com.example.chatbot.service.*;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/projects")
public class ProjectController {

    private final UserService userService;
    private final ProjectService projectService;

    public ProjectController(UserService userService, ProjectService projectService) {
        this.userService = userService;
        this.projectService = projectService;
    }

    @PostMapping
    public ResponseEntity<?> createProject(@RequestBody Map<String, String> body, Authentication auth) {
        String email = auth.getName();
        User user = userService.findByEmail(email).orElseThrow(new RuntimeException("User not found"));
        Project p = projectService.createProject(user, body.get("name"), body.get("description"));
        return ResponseEntity.ok(p);
    }

    @GetMapping
    public ResponseEntity<?> listProjects(Authentication auth) {
        String email = auth.getName();
        User user = userService.findByEmail(email).orElseThrow(new RuntimeException("User not found"));
        List<Project> list = projectService.listByOwner(user);
        return ResponseEntity.ok(list);
    }
}
