package com.example.chatbot.controller;

import com.example.chatbot.dto.ChatRequest;
import com.example.chatbot.entity.*;
import com.example.chatbot.repository.PromptRepository;
import com.example.chatbot.service.*;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/chat")
public class ChatController {

    private final UserService userService;
    private final ProjectService projectService;
    private final ChatService chatService;
    private final PromptRepository promptRepo;

    public ChatController(UserService userService, ProjectService projectService, ChatService chatService, PromptRepository promptRepo) {
        this.userService = userService;
        this.projectService = projectService;
        this.chatService = chatService;
        this.promptRepo = promptRepo;
    }

    @PostMapping("/ask")
    public ResponseEntity<?> ask(@RequestBody ChatRequest req, Authentication auth) {
        User user = userService.findByEmail(auth.getName()).orElseThrow(new RuntimeException("User not found"));
        Project project = projectService.getById(req.getProjectId()).orElseThrow(new RuntimeException("Project not found"));
        if (!project.getOwner().getId().equals(user.getId())) {
            return ResponseEntity.status(403).body("Not authorized for this project");
        }

        Prompt systemPrompt = null;
        if (req.getPromptId() != null) {
            systemPrompt = promptRepo.findById(req.getPromptId()).orElse(null);
        }

        String assistant = chatService.askModel(project, req.getMessage(), systemPrompt);
        return ResponseEntity.ok(Collections.singletonMap("assistant", assistant));
    }

    @GetMapping("/history/{projectId}")
    public ResponseEntity<?> history(@PathVariable Long projectId, Authentication auth) {
        User user = userService.findByEmail(auth.getName()).orElseThrow(new RuntimeException("User not found"));
        Project project = projectService.getById(projectId).orElseThrow(new RuntimeException("Project not found"));
        if (!project.getOwner().getId().equals(user.getId())) return ResponseEntity.status(403).build();
        List<Message> messages = chatService.getConversation(project);
        return ResponseEntity.ok(messages);
    }
}
