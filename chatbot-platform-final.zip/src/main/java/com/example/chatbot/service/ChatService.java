package com.example.chatbot.service;

import com.example.chatbot.entity.*;
import com.example.chatbot.repository.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.*;
import reactor.core.publisher.Mono;
import java.util.List;
import java.util.Collections;

@Service
public class ChatService {

    private final MessageRepository messageRepo;
    private final ProjectRepository projectRepo;
    private final PromptRepository promptRepo;
    private final WebClient webClient;
    private final String openaiApiKey;
    private final String openaiBaseUrl;

    public ChatService(MessageRepository messageRepo,
                       ProjectRepository projectRepo,
                       PromptRepository promptRepo,
                       @Value("${llm.openai.apiKey:}") String openaiApiKey,
                       @Value("${llm.openai.baseUrl:https://api.openai.com/v1/responses}") String openaiBaseUrl) {
        this.messageRepo = messageRepo;
        this.projectRepo = projectRepo;
        this.promptRepo = promptRepo;
        this.openaiApiKey = openaiApiKey;
        this.openaiBaseUrl = openaiBaseUrl;
        this.webClient = WebClient.builder().baseUrl(openaiBaseUrl).defaultHeader("Authorization", "Bearer " + openaiApiKey).build();
    }

    public List<Message> getConversation(Project p) { return messageRepo.findByProjectOrderByIdAsc(p); }

    public Message saveUserMessage(Project p, String content) {
        Message m = new Message(); m.setProject(p); m.setRole("user"); m.setContent(content); return messageRepo.save(m);
    }

    public Message saveAssistantMessage(Project p, String content) {
        Message m = new Message(); m.setProject(p); m.setRole("assistant"); m.setContent(content); return messageRepo.save(m);
    }

    public String askModel(Project project, String userMessage, Prompt systemPrompt) {
        saveUserMessage(project, userMessage);
        String combined = (systemPrompt != null ? systemPrompt.getContent() + "\n" : "") + userMessage;
        if (openaiApiKey == null || openaiApiKey.isEmpty()) {
            String reply = "(LLM disabled) Echo: " + userMessage;
            saveAssistantMessage(project, reply);
            return reply;
        }
        Mono<String> resp = webClient.post().bodyValue(java.util.Collections.singletonMap("input", combined)).retrieve().bodyToMono(String.class);
        String responseText = resp.block();
        String assistantText = extractTextFromOpenAIResponse(responseText);
        saveAssistantMessage(project, assistantText);
        return assistantText;
    }

    private String extractTextFromOpenAIResponse(String rawJson) {
        try {
            com.fasterxml.jackson.databind.ObjectMapper m = new com.fasterxml.jackson.databind.ObjectMapper();
            com.fasterxml.jackson.databind.JsonNode root = m.readTree(rawJson);
            if (root.has("output") && root.get("output").isArray()) {
                com.fasterxml.jackson.databind.JsonNode out0 = root.get("output").get(0);
                if (out0.has("content") && out0.get("content").isArray()) {
                    for (com.fasterxml.jackson.databind.JsonNode c : out0.get("content")) {
                        if (c.has("text")) return c.get("text").asText();
                        if (c.has("markdown")) return c.get("markdown").asText();
                    }
                }
            }
            if (root.has("output_text")) return root.get("output_text").asText();
            return rawJson;
        } catch (Exception ex) {
            return rawJson;
        }
    }
}
