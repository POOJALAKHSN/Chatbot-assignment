package com.example.chatbot.service;

import com.example.chatbot.entity.Project;
import com.example.chatbot.entity.User;
import com.example.chatbot.repository.ProjectRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class ProjectService {
    private final ProjectRepository projectRepo;
    public ProjectService(ProjectRepository projectRepo) { this.projectRepo = projectRepo; }
    public Project createProject(User owner, String name, String desc) {
        Project p = new Project();
        p.setOwner(owner);
        p.setName(name);
        p.setDescription(desc);
        return projectRepo.save(p);
    }
    public List<Project> listByOwner(User owner) { return projectRepo.findByOwner(owner); }
    public Optional<Project> getById(Long id) { return projectRepo.findById(id); }
}
