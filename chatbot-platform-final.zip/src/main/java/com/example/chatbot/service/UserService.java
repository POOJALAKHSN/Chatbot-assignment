package com.example.chatbot.service;

import com.example.chatbot.entity.User;
import com.example.chatbot.repository.UserRepository;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service
public class UserService {
    private final UserRepository userRepo;
    private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

    public UserService(UserRepository userRepo) { this.userRepo = userRepo; }

    public User register(String email, String password, String fullName) {
        User u = new User();
        u.setEmail(email);
        u.setPasswordHash(encoder.encode(password));
        u.setFullName(fullName);
        return userRepo.save(u);
    }

    public Optional<User> findByEmail(String email) { return userRepo.findByEmail(email); }

    public boolean checkPassword(String raw, String encoded) { return encoder.matches(raw, encoded); }
}
