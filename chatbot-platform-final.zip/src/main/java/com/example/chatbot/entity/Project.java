package com.example.chatbot.entity;

import javax.persistence.*;
import lombok.*;

@Entity
@Table(name = "project")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Project {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional=false)
    @JoinColumn(name="user_id")
    private User owner;

    private String name;

    @Column(columnDefinition="text")
    private String description;
}
