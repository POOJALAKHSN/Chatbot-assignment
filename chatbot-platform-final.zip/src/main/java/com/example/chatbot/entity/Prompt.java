package com.example.chatbot.entity;

import javax.persistence.*;
import lombok.*;

@Entity
@Table(name = "prompt")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Prompt {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional=false)
    @JoinColumn(name="project_id")
    private Project project;

    private String name;

    @Column(columnDefinition="text")
    private String content;
}
