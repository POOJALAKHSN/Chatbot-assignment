package com.example.chatbot.entity;

import javax.persistence.*;
import lombok.*;

@Entity
@Table(name = "message")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Message {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional=false)
    @JoinColumn(name="project_id")
    private Project project;

    private String role;

    @Column(columnDefinition="text")
    private String content;
}
