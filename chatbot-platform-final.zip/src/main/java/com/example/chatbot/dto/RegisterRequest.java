package com.example.chatbot.dto;
public class RegisterRequest {
    private String email;
    private String password;
    private String fullName;
    public String getEmail(){return email;} public void setEmail(String e){this.email=e;}
    public String getPassword(){return password;} public void setPassword(String p){this.password=p;}
    public String getFullName(){return fullName;} public void setFullName(String f){this.fullName=f;}
}
