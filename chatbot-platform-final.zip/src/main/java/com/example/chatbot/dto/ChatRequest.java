package com.example.chatbot.dto;
public class ChatRequest {
    private Long projectId;
    private String message;
    private Long promptId;
    public Long getProjectId(){return projectId;} public void setProjectId(Long p){this.projectId=p;}
    public String getMessage(){return message;} public void setMessage(String m){this.message=m;}
    public Long getPromptId(){return promptId;} public void setPromptId(Long p){this.promptId=p;}
}
