# Chatbot Platform - Final (Java 8 compatible)

Unzip and run (PowerShell):
1. cd to folder
2. powershell -ExecutionPolicy Bypass -File .\run.ps1
App starts at http://localhost:8080
